import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export default function EmpreendifySite() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 to-slate-300 text-gray-800 p-6">
      <header className="text-center py-10">
        <h1 className="text-4xl font-bold text-slate-800">Empreendify</h1>
        <p className="text-lg text-slate-600 mt-2">Soluções inteligentes para organização empresarial</p>
      </header>

      <section className="max-w-4xl mx-auto grid gap-8">
        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-4">Quem Somos</h2>
            <p>
              A Empreendify nasceu para ajudar empresas a se organizarem, otimizarem processos e alcançarem mais resultados com menos esforço. Atuamos com análise de estrutura, fluxos de trabalho, e entregamos soluções personalizadas para seu negócio crescer de forma sustentável.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-4">Serviços</h2>
            <ul className="list-disc pl-5 space-y-2">
              <li>Diagnóstico organizacional</li>
              <li>Mapeamento de processos</li>
              <li>Plano de melhoria personalizada</li>
              <li>Suporte estratégico para gestores</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-4">Solicite sua Análise Gratuita</h2>
            <form className="grid gap-4">
              <Input placeholder="Seu nome" required />
              <Input placeholder="Seu e-mail" type="email" required />
              <Textarea placeholder="Fale um pouco sobre sua empresa..." required />
              <Button className="bg-slate-800 text-white hover:bg-slate-700">Enviar</Button>
            </form>
          </CardContent>
        </Card>
      </section>

      <footer className="text-center text-slate-600 text-sm mt-10">
        &copy; 2025 Empreendify. Todos os direitos reservados.
      </footer>
    </div>
  )
}
